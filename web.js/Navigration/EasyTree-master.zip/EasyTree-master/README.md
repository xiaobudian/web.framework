EasyTree
========

EasyTree Jquery Plugin


EasyTree is a free jquery plugin designed to easiliy convert ul lists or json to tree menus

Instructions
=============

<ol>
<li>Copy the js file to your site along with the skin of your choosing. 
<li>Make sure you have already imported jquery 1.7 or later.
<li>Go to http://www.easyjstree.com to find out more
</ol>
